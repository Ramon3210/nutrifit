import React, { Component } from 'react';

class Footer extends Component {
    state = {  }
    render() { 
        return ( 
            <div className="App-footer">
                <h3>DERECHOS RESERVADOS 2020@</h3>
            </div>
         );
    }
}
 
export default Footer;